use strict;
use warnings;
use Digest::SHA qw(sha256_hex);
use JSON::PP;
my $base = '.tmp/canic176-readability';
sub read_file { my ($path)=@_; open my $f,'<',$path or die "$path: $!"; local $/; return <$f>; }
my @checks;
for my $entry (
    ['build-tests', 'cargo test --locked -p canic-cli --lib build::tests'],
    ['display-tests', 'cargo test --locked -p canic-cli --lib support::build'],
    ['help-tests', 'cargo test --locked -p canic-cli --test subcommand_order'],
    ['reuse-tests', 'cargo test --locked -p canic-host --lib canister_build::reuse::tests::complete::verified_repeat_survives_missing_diagnostics_and_rejects_tampered_output'],
    ['environment-tests', 'cargo test --locked -p canic-host --lib canister_build::reuse::tests::complete::environment::launcher_shell_depth_and_credentials_preserve_reuse_while_build_inputs_invalidate'],
) {
    my ($id,$command)=@$entry;
    my $log=read_file("$base/$id.log");
    my @passed=$log =~ /test result: ok\. (\d+) passed; 0 failed;/g;
    die "Missing successful nonempty test result: $id" unless @passed && $passed[-1]>0;
    push @checks,{id=>$id,command=>$command,log=>"$id.log",passed=>0+$passed[-1],result=>'pass'};
}
my $clippy=read_file("$base/clippy.log");
die 'Clippy did not complete successfully' unless $clippy =~ /Finished `dev` profile/ && $clippy !~ /^error:/m;
push @checks,{id=>'clippy',command=>'cargo clippy --locked -p canic-cli --lib --tests -- -D warnings',log=>'clippy.log',result=>'pass'};
my $delta=decode_json(read_file("$base/source-delta.json"));
my $report={
    schema_version=>1,date=>'2026-09-25',issue=>'CANIC-176',result=>'pass',
    scope=>'CLI build-cache presentation follow-up within the open 0.110.42 batch',
    package_version=>'0.110.41',open_patch=>'0.110.42',
    feedback=>{commit=>'6166d79c3b083892fb218114ac5af80b07bdf295',path=>'toko-miner/docs/upstream/canic.md',sha256=>'467038bd808d51b9c33b7e768cedbaa936a7455dee6f167eccf839ab45aab98a'},
    source=>$delta,
    checks=>\@checks,
    environment=>{CARGO_NET_OFFLINE=>'true',CARGO_BUILD_JOBS=>'2',CARGO_INCREMENTAL=>'0',RUSTC_WRAPPER=>''},
    invariants=>['Shared verified hits and misses are summarized once with artifact count', 'Detailed bounded host attribution is available once with --verbose', 'Distinct rejection errors remain visible', 'Checking/waiting share the existing TTY-bounded display; redirected phase output has no cursor controls', 'Cache admission, environment normalization/binding and output verification are unchanged'],
    records=>{file=>'canic176-readability-records.tar.gz',sha256=>sha256_hex(read_file("$base/canic176-readability-records.tar.gz"))},
    b5_disposition=>'Retain B5 exact-source measurements. All recorded non-CLI product inputs match; this additive record qualifies the CLI-only delta. No new artifact/instruction or full-suite measurement is claimed.',
    limitations=>['Terminal width/resize behavior uses the actual painter with in-memory writers; no new real PTY or downstream launcher run is claimed', 'Toko adoption and application acceptance remain downstream work', 'No version transaction, Git publication, deployment or next-minor implementation ran', 'Human acceptance of the exact 0.110 audit including this delta remains pending'],
};
print JSON::PP->new->pretty->canonical->encode($report);
