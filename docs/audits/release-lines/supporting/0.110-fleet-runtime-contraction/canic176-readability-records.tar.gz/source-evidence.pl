use strict;
use warnings;
use Digest::SHA qw(sha256_hex);
use JSON::PP;
my $base = '.tmp/canic176-readability';
my $prior = '.tmp/b5-qualification-20260925/method/source-files.sha256';
sub digest {
    my ($path) = @_;
    open my $f, '<', $path or die "$path: $!";
    binmode $f;
    local $/;
    return sha256_hex(<$f>);
}
open my $input, '<', $prior or die $!;
my (@delta, @manifest);
while (<$input>) {
    chomp;
    my ($old, $path) = split /  /, $_, 2;
    my $new = digest($path);
    push @manifest, "$new  $path\n";
    next if $old eq $new;
    die "Unexpected non-CLI source change: $path" unless $path =~ m{^crates/canic-cli/};
    push @delta, {path => $path, before => $old, after => $new};
}
my $added = 'crates/canic-cli/src/support/build_cache/mod.rs';
push @manifest, digest($added)."  $added\n";
push @delta, {path => $added, before => undef, after => digest($added)};
open my $output, '>', "$base/source-files.sha256" or die $!;
print {$output} sort { (split /  /, $a, 2)[1] cmp (split /  /, $b, 2)[1] } @manifest;
close $output or die $!;
open my $json, '>', "$base/source-delta.json" or die $!;
print {$json} JSON::PP->new->pretty->canonical->encode({
    prior_source_manifest_sha256 => digest($prior),
    source_manifest_sha256 => digest("$base/source-files.sha256"),
    unchanged_non_cli_product_inputs => JSON::PP::true,
    changes => \@delta,
});
