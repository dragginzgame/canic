from pathlib import Path
import hashlib,json,re,subprocess,sys
from wasm_metrics import var,string

root=Path(sys.argv[1]);original=root/'test.wasm'
def sections(data):
    result={};custom=[];pos=8
    while pos<len(data):
        kind=data[pos];length,start=var(data,pos+1);end=start+length
        if kind:result[kind]=data[start:end]
        else:custom.append(data[pos:end])
        pos=end
    return result,custom
def bodies(payload):
    count,pos=var(payload,0);result=[]
    for _ in range(count):
        size,start=var(payload,pos);result.append(payload[start:start+size]);pos=start+size
    assert pos==len(payload)
    return result
def globals(payload):
    count,pos=var(payload,0);return count,payload[pos:]

data=original.read_bytes();old,custom=sections(data)
subprocess.run(['wasm2wat','--no-debug-names',str(original),'-o',str(root/'instruction-original.wat')],check=True)
wat=(root/'instruction-original.wat').read_text()
imports={name:int(index) for name,index in re.findall(r'^  \(import "ic0" "([^"]+)" \(func \(;(\d+);\)',wat,re.M)}
exports={name:int(index) for name,index in re.findall(r'^  \(export "([^"]+)" \(func (\d+)\)\)',wat,re.M)}
selected=['canister_init','canister_post_upgrade','canister_update qualify_history_sampling_cost']
assert all(name in exports for name in selected)
assert 'canister_query canic_b2_instruction_cost' not in exports
assert all(name in imports for name in ['performance_counter','msg_reply_data_append','msg_reply'])
# This method only wraps synchronous init/restore and the local-only sampling
# handler. It is not an end-to-end asynchronous/inter-canister cost meter.
function_count=var(old[3],0)[0]+var(old[2],0)[0]
global_count,old_global_bytes=globals(old[6])
additions=[f'  (global (;{global_count};) (mut i64) (i64.const 0))',
    f'  (global (;{global_count+1};) (mut i64) (i64.const 0))']
for stage,name in enumerate(selected):
    new_index=function_count+stage
    before=f'  (export "{name}" (func {exports[name]}))'
    after=f'  (export "{name}" (func {new_index}))'
    assert wat.count(before)==1;wat=wat.replace(before,after)
    additions.append(f'''  (func (;{new_index};) (local i64)
    i32.const 0
    call {imports['performance_counter']}
    local.set 0
    call {exports[name]}
    i32.const 0
    call {imports['performance_counter']}
    local.get 0
    i64.sub
    global.set {global_count}
    i64.const {stage}
    global.set {global_count+1})''')
# The diagnostic query writes a Candid tuple to low scratch bytes only in its
# discarded query heap. It calls no original function and changes no update heap.
header=int.from_bytes(b'DIDL\x00\x02\x78\x78','little')
additions.append(f'''  (func (;{function_count+3};)
    i32.const 0
    i64.const {header}
    i64.store
    i32.const 8
    global.get {global_count+1}
    i64.store
    i32.const 16
    global.get {global_count}
    i64.store
    i32.const 0
    i32.const 24
    call {imports['msg_reply_data_append']}
    call {imports['msg_reply']})
  (export "canister_query canic_b2_instruction_cost" (func {function_count+3}))''')
wat=wat.rstrip();assert wat.endswith(')');wat=wat[:-1]+'\n'+'\n'.join(additions)+'\n)\n'
(root/'instruction-wrapped.wat').write_text(wat)
wrapped=root/'instruction-wrapped.wasm'
subprocess.run(['wat2wasm',str(root/'instruction-wrapped.wat'),'-o',str(wrapped)],check=True)
instrumented=wrapped.read_bytes();new,new_custom=sections(instrumented);assert not new_custom
if 12 in old and 12 not in new:
    def leb(value):
        output=bytearray()
        while value>=128:output.append((value&127)|128);value>>=7
        output.append(value);return bytes(output)
    pos=8
    while instrumented[pos]!=10:
        length,start=var(instrumented,pos+1);pos=start+length
    instrumented=instrumented[:pos]+bytes([12])+leb(len(old[12]))+old[12]+instrumented[pos:]
    new,new_custom=sections(instrumented)
assert bodies(new[10])[:-4]==bodies(old[10]),'original executable bodies changed'
assert var(new[3],0)[0]==var(old[3],0)[0]+4
assert globals(new[6])[0]==global_count+2
assert globals(new[6])[1].startswith(old_global_bytes)
for kind in old:
    if kind not in [1,3,6,7,10]:assert old[kind]==new[kind],('section changed',kind)
# Restore the original non-executable custom metadata omitted by WAT printing.
wrapped.write_bytes(instrumented+b''.join(custom))
subprocess.run(['wasm-validate',str(wrapped)],check=True)
report={'schema_version':1,'original_sha256':hashlib.sha256(data).hexdigest(),
    'wrapped_sha256':hashlib.sha256(wrapped.read_bytes()).hexdigest(),
    'original_defined_bodies_byte_identical':len(bodies(old[10])),
    'unchanged_non_executable_custom_sections':len(custom),
    'wrappers':{name:{'stage':stage,'original_index':exports[name],'wrapper_index':function_count+stage} for stage,name in enumerate(selected)},
    'measurement_overhead':'Both conditions include the same local.set/call/i32.const sequence between counter reads; no subtraction.',
    'scope':'Synchronous selected export execution, including preflight and guard; excludes deferred timer work and later callbacks.'}
(root/'instruction-wrapper.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
