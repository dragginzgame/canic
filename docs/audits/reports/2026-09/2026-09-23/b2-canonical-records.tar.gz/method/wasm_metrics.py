from pathlib import Path
import gzip, hashlib, json
base=Path(__file__).resolve().parent

def var(data, offset):
 value=0; shift=0
 while True:
  byte=data[offset];offset+=1;value|=(byte&127)<<shift
  if byte<128:return value,offset
  shift+=7

def string(data,offset):
 length,offset=var(data,offset)
 return data[offset:offset+length].decode(),offset+length

def inspect(path):
 data=path.read_bytes(); assert data[:8]==b'\0asm\x01\0\0\0'
 sections={};names={};offset=8
 while offset<len(data):
  kind=data[offset];length,start=var(data,offset+1);payload=data[start:start+length];offset=start+length
  if kind:sections[kind]=payload
  else:
   name,cursor=string(payload,0)
   if name=='name':
    while cursor<len(payload):
     sub=payload[cursor];size,start=var(payload,cursor+1);cursor=start+size
     if sub==1:
      count,pos=var(payload,start)
      for _ in range(count):
       index,pos=var(payload,pos);name,pos=string(payload,pos);names[index]=name
 exports=[]
 payload=sections.get(7,b'\0');count,pos=var(payload,0)
 for _ in range(count):
  name,pos=string(payload,pos);kind=payload[pos];index,pos=var(payload,pos+1)
  exports.append(dict(name=name,kind=kind))
 code=sections.get(10,b'\0');functions,_=var(code,0)
 decls,_=var(sections.get(3,b'\0'),0);assert functions==decls
 tables=[]
 table_payload=sections.get(4,b'\0');table_count,pos=var(table_payload,0)
 for _ in range(table_count):
  ref=table_payload[pos];pos+=1;assert ref in (0x70,0x6f)
  flags,pos=var(table_payload,pos);assert flags in (0,1)
  initial,pos=var(table_payload,pos)
  maximum=None
  if flags&1: maximum,pos=var(table_payload,pos)
  tables.append(dict(reference_type=ref,initial=initial,maximum=maximum))
 elements=sections.get(9,b'\0');element_count,pos=var(elements,0);element_entries=0
 for _ in range(element_count):
  flags,pos=var(elements,pos);assert flags==0,('unsupported element flags',flags)
  assert elements[pos]==0x41;_,pos=var(elements,pos+1);assert elements[pos]==0x0b;pos+=1
  count,pos=var(elements,pos);element_entries+=count
  for _ in range(count):_,pos=var(elements,pos)
 assert pos==len(elements)
 return dict(element_entries=element_entries,sha256=hashlib.sha256(data).hexdigest(),raw_bytes=len(data),gzip_bytes=len(gzip.compress(data,mtime=0)),code_section_bytes=len(code),data_section_bytes=len(sections.get(11,b'')),defined_functions=functions,table_count=table_count,table_slots=sum(t["initial"] for t in tables),tables=tables,element_segments=var(sections.get(9,b'\0'),0)[0],exports=sorted(exports,key=lambda row:row['name']),admission_named_functions=[dict(index=i,name=n) for i,n in names.items() if 'fleet_admission_projection' in n])
