from pathlib import Path
import json,re,itertools,hashlib,subprocess
import sys
root=Path(sys.argv[1])
exec(Path(__file__).with_name('map-functions.py').read_text().split('n,ni=parse')[0])
n,ni=parse(root/'named.wat');c,ci=parse(root/'canonical.wat');candidates={int(k):v for k,v in json.loads((root/'canonical-function-map.json').read_text()).items()}
wat=(root/'named.wat').read_text();anchors={int(i) for i in re.findall(r'^  \(export .*?\(func (\d+)\)',wat,re.M)}
for line in wat.splitlines():
 if line.startswith('  (elem '):
  m=re.search(r' func ([\d ]+)\)',line);assert m;anchors.update(map(int,m[1].split()))
anchors.update(ni)
# Bind export/table/import roots before solving indistinguishable leaf bodies.
domains={i:set(v) for i,v in candidates.items()}
for i in anchors:
 assert i in domains[i], ('anchor mismatch',i)
 domains[i]={i}

def propagate(domains):
 while True:
  if any(not values for values in domains.values()):return None
  fixed={i:next(iter(v)) for i,v in domains.items() if len(v)==1}
  if len(set(fixed.values()))!=len(fixed):return None
  used=set(fixed.values()); changed=False
  for i,values in domains.items():
   if len(values)>1:
    reduced=values-used
    if reduced!=values:domains[i]=reduced;changed=True
  if any(not values for values in domains.values()):return None
  for i,(_,calls) in n.items():
   old=domains[i]
   new={j for j in old if all(ct in domains[nt] for nt,ct in zip(calls,c[j][1]))}
   if not new:return None
   if new!=old:domains[i]=new;changed=True
   for position,nt in enumerate(calls):
    supported={c[j][1][position] for j in new}
    reduced=domains[nt]&supported
    if not reduced:return None
    if reduced!=domains[nt]:domains[nt]=reduced;changed=True
  if not changed:return domains

def solve(domains):
 domains=propagate(domains)
 if domains is None:return None
 unresolved=[i for i,v in domains.items() if len(v)>1]
 if not unresolved:return {i:next(iter(v)) for i,v in domains.items()}
 i=min(unresolved,key=lambda i:len(domains[i]))
 for j in sorted(domains[i]):
  branch={k:set(v) for k,v in domains.items()};branch[i]={j}
  result=solve(branch)
  if result is not None:return result
 return None

mapping=solve(domains)
assert mapping is not None,'no complete reference-preserving bijection'
assert len(set(mapping.values()))==len(mapping)
assert all(mapping[i]==i for i in anchors)
assert all(mapping[i] in candidates[i] for i in mapping)
assert all(n[i][0]==c[mapping[i]][0] for i in n)
assert all(len(calls)==len(c[mapping[i]][1]) and all(mapping[nc]==cc for nc,cc in zip(calls,c[mapping[i]][1])) for i,(_,calls) in n.items())
assert all(ni[i]==ci[mapping[i]] for i in ni)
assert len(mapping)==len(n)+len(ni)==len(c)+len(ci)
# All signatures/non-reference instructions were checked by the candidate map;
# this witness additionally checks every call target and export/table/import root.
(root/'canonical-bijection.json').write_text(json.dumps({'all_functions':len(mapping),'anchors':len(anchors),'bijection':mapping,'all_calls_preserved':True,'all_export_table_import_bindings_preserved':True},indent=2)+'\n')
print('complete bijection',len(mapping),'anchors',len(anchors))
