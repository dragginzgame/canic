from pathlib import Path
import re,json,hashlib,sys
root=Path(sys.argv[1])
b=(root/'raw.wasm').read_bytes()
def leb(b,p):
 n=s=0
 while True:
  v=b[p];p+=1;n|=(v&127)<<s
  if v<128:return n,p
  s+=7

def enc(n):
 out=bytearray()
 while n>=128:out.append((n&127)|128);n>>=7
 out.append(n);return bytes(out)

def string(b,p):
 n,p=leb(b,p);return b[p:p+n].decode(),p+n

def estr(s):
 b=s.encode();return enc(len(b))+b
assert b[:8]==b'\0asm\1\0\0\0'
ss={};headers={};p=8
while p<len(b):
 sid=b[p];size,q=leb(b,p+1)
 if sid: ss[sid]=(q,b[q:q+size]);headers[sid]=q-p
 p=q+size
imports=[];z=ss[2][1];n,p=leb(z,0)
for _ in range(n):
 module,p=string(z,p);name,p=string(z,p);kind=z[p];p+=1;assert kind==0;ty,p=leb(z,p);imports.append((module,name,ty))
assert p==len(z)
by_offset={}
for line in (root/'link-map.txt').read_text().splitlines():
 m=re.match(r'^\s*-\s+([0-9a-f]+)\s+([0-9a-f]+)\s+([^\s]+)\s*$',line)
 if not m:continue
 off,size,symbol=int(m[1],16),int(m[2],16),m[3]
 if symbol.startswith('<internal>:('):symbol=symbol[len('<internal>:('):-1]
 if ':' in symbol or symbol in ['TYPE','IMPORT','FUNCTION','TABLE','MEMORY','GLOBAL','EXPORT','ELEM','CODE','DATA','CUSTOM']:continue
 by_offset.setdefault(off,[]).append((size,symbol))
base,z=ss[10];n,p=leb(z,0);names={};rows=[]
for i in range(n):
 start=p;size,q=leb(z,p);body=z[q:q+size];p=q+size
 matches=[]
 for off in [base+start-headers[10]]:
  for msize,symbol in by_offset.get(off,[]):
   if msize == p-start:matches.append((off,msize,symbol))
 if matches:
  symbols=sorted({sym for _,_,sym in matches});chosen=next((s for s in symbols if s.startswith('_R')),symbols[0]);names[i+len(imports)]=chosen
  rows.append({'function_index':i+len(imports),'body_offset':base+q,'body_bytes':size,'body_sha256':hashlib.sha256(body).hexdigest(),'symbols':symbols,'matches':matches})
assert p==len(z)
sub=enc(len(names))+b''.join(enc(i)+estr(name) for i,name in sorted(names.items()));custom=estr('name')+bytes([1])+enc(len(sub))+sub
(root/'raw-with-names.wasm').write_bytes(b+b'\0'+enc(len(custom))+custom)
(root/'link-name-map.json').write_text(json.dumps({'raw_sha256':hashlib.sha256(b).hexdigest(),'imports':imports,'defined_functions':n,'named_functions':len(names),'functions':rows},indent=2)+'\n')
print('defined',n,'names',len(names))
