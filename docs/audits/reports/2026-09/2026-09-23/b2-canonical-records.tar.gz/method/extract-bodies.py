from pathlib import Path
import hashlib,json,subprocess,sys
from wasm_metrics import var,string
root=Path(sys.argv[1]);role=sys.argv[2]
def sections(b):
 result={};p=8
 while p<len(b):
  kind=b[p];size,start=var(b,p+1)
  if kind:result[kind]=b[start:start+size]
  p=start+size
 return result
canonical=(root/f'{role}.wasm').read_bytes();named=(root/'optimized-with-names.wasm').read_bytes()
cs,ns=sections(canonical),sections(named)
assert cs.keys()==ns.keys()
for key in cs:
 if key not in [1,3,10]:assert cs[key]==ns[key],('non-code section mismatch',key)
imports,pos=var(cs[2],0)
for _ in range(imports):
 _,pos=string(cs[2],pos);_,pos=string(cs[2],pos);assert cs[2][pos]==0;_,pos=var(cs[2],pos+1)
assert pos==len(cs[2])
bodies={};count,pos=var(cs[10],0)
for i in range(count):
 size,start=var(cs[10],pos);bodies[imports+i]=cs[10][start:start+size];pos=start+size
assert pos==len(cs[10])
names={};pos=8
while pos<len(named):
 kind=named[pos];size,start=var(named,pos+1);end=start+size
 if kind==0:
  key,p=string(named,start)
  if key=='name':
   while p<end:
    sub=named[p];length,q=var(named,p+1);p=q+length
    if sub==1:
     n,q=var(named,q)
     for _ in range(n):
      i,q=var(named,q);name,q=string(named,q);names[i]=name
 pos=end
indices=list(names)
demangled=subprocess.check_output(['c++filt','-s','rust'],input=('\n'.join(names[i] for i in indices)+'\n').encode()).decode().splitlines()
assert len(indices)==len(demangled)
witness=json.loads((root/'canonical-bijection.json').read_text());mapping={int(i):j for i,j in witness['bijection'].items()}
patterns={
 'admission_projection':'fleet_admission_projection',
 'admission_storage':'storage::stable::fleet_admission_projection',
 'core_stable_auth':'storage::stable::auth::',
 'access_evaluator':'::access::expr::',
 'core_sharding':'storage::stable::sharding',
 'async_job_recovery':'storage::stable::async_job_recovery',
 'authority_restore':'storage::stable::authority_restore',
 'control_plane_storage':('canic_control_plane','::storage::stable::'),
 'generic_page':'Page<',
}
selected={key:[] for key in patterns}
for i,name in zip(indices,demangled):
 j=mapping[i]
 if j not in bodies:continue
 for family,needle in patterns.items():
  needles=(needle,) if isinstance(needle,str) else needle
  if not all(part in name for part in needles):continue
  body=bodies[j]
  selected[family].append(dict(canonical_index=j,name=name,symbol=names[i],body_bytes=len(body),body_sha256=hashlib.sha256(body).hexdigest()))
report=dict(role=role,canonical_sha256=hashlib.sha256(canonical).hexdigest(),named_sha256=hashlib.sha256(named).hexdigest(),non_code_sections_exact=True,all_functions_bijective=witness['all_functions'],defined_functions=count,selected_families=selected)
(root/'canonical-storage-bodies.json').write_text(json.dumps(report,indent=2)+'\n')
for key,rows in selected.items():print(key,len(rows))
