#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
condition="$1"
id="$2"
role="${3:-$id}"
capture="$base/results/$condition/$id"
python3 "$base/attach-link-names.py" "$capture"
ic-wasm "$capture/raw-with-names.wasm" -o "$capture/preopt-with-names.wasm" shrink --keep-name-section
ic-wasm "$capture/preopt-with-names.wasm" -o "$capture/preopt-with-names.wasm" metadata --keep-name-section candid:service -f "$capture/$role.did" -v public
wasm-opt "$capture/preopt-with-names.wasm" --enable-bulk-memory --enable-sign-ext --enable-nontrapping-float-to-int --print-features > "$capture/features.txt"
mapfile -t features < "$capture/features.txt"
wasm-opt "$capture/preopt-with-names.wasm" -o "$capture/optimized-with-names.wasm" -Oz -g "${features[@]}"
wasm2wat --no-debug-names "$capture/optimized-with-names.wasm" -o "$capture/named.wat"
wasm2wat --no-debug-names "$capture/$role.wasm" -o "$capture/canonical.wat"
python3 "$base/map-functions.py" "$capture"
timeout 45s python3 "$base/verify-map.py" "$capture"
