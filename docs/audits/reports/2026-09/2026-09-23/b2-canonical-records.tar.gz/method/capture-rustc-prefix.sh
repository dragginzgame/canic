#!/usr/bin/env bash
set -euo pipefail
compiler="$1"
shift
args=("$@")
selected=false
wasm=false
output_dir=''
previous=''
for arg in "$@"; do
    if [[ "$previous" == --crate-name && "$arg" == "${B2_CAPTURE_CRATE:-}" ]]; then selected=true; fi
    if [[ "$previous" == --target && "$arg" == wasm32-unknown-unknown ]]; then wasm=true; fi
    if [[ "$previous" == --out-dir ]]; then output_dir="$arg"; fi
    previous="$arg"
done
if [[ "$selected" == true && "$wasm" == true ]]; then
    args+=(-C "link-arg=--Map=$B2_CAPTURE_DIR/link-map.txt" -C link-arg=--no-demangle)
fi
"$compiler" "${args[@]}"
if [[ "$selected" == true && "$wasm" == true ]]; then
    shopt -s nullglob
    outputs=("$output_dir"/"$B2_CAPTURE_CRATE"*.wasm)
    [[ "${#outputs[@]}" -eq 1 ]]
    cp "${outputs[0]}" "$B2_CAPTURE_DIR/raw.wasm"
fi
