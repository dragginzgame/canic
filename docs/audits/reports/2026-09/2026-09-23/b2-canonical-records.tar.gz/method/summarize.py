from pathlib import Path
import gzip,hashlib,json,subprocess
from wasm_metrics import inspect
base=Path(__file__).resolve().parent
report={}
for artifact in json.loads((base/'artifacts.json').read_text()):
 role=artifact['role']; artifact_id=artifact['id']
 if not (base/'results'/'after'/artifact_id/'role-build-output.txt').exists():continue
 rows={}
 for condition in ['before','after']:
  root=base/'results'/condition/artifact_id
  wasm=root/f'{role}.wasm';compressed=root/f'{role}.wasm.gz';did=root/f'{role}.did'
  assert gzip.decompress(compressed.read_bytes())==wasm.read_bytes()
  row=inspect(wasm);row['gzip_bytes']=compressed.stat().st_size
  row['gzip_sha256']=hashlib.sha256(compressed.read_bytes()).hexdigest()
  row['candid_bytes']=did.stat().st_size;row['candid_sha256']=hashlib.sha256(did.read_bytes()).hexdigest()
  transforms=json.loads((root/'transforms.json').read_text())
  assert transforms['schema_version']==1 and transforms['role']==role
  opt=[r for r in transforms['transforms'] if r['transform']=='optimize' and r['outcome']=='applied']
  assert len(opt)==1
  for key,value in opt[0]['metrics']['after'].items():assert row[key]==value,(condition,role,key,row[key],value)
  assert row['defined_functions']==int((root/'defined-functions.txt').read_text())
  row['code_reserve_bytes']=10*1024*1024-row['code_section_bytes']
  row['function_reserve']=50000-row['defined_functions']
  assert row['code_reserve_bytes']>=512*1024
  assert row['function_reserve']>=2500
  assert row['raw_bytes']<100*1024*1024
  flags=[line for line in (root/'role-build-output.txt').read_text().splitlines() if line.startswith('cargo:rustc-cfg=canic_')]
  row['role_cfgs']=sorted(flags)
  if (root/'generated-Cargo.toml').exists():
   row['generated_manifest_sha256']=hashlib.sha256((root/'generated-Cargo.toml').read_bytes()).hexdigest()
  rows[condition]=row
 assert rows['before'].get('generated_manifest_sha256')==rows['after'].get('generated_manifest_sha256')
 assert rows['before']['exports']==rows['after']['exports']
 assert rows['before']['role_cfgs']==rows['after']['role_cfgs']
 assert rows['before']['candid_sha256']==rows['after']['candid_sha256']
 report[artifact_id]=dict(artifact=artifact,**rows,delta={key:rows['after'][key]-rows['before'][key] for key in ['raw_bytes','gzip_bytes','code_section_bytes','data_section_bytes','defined_functions','table_slots','element_segments','element_entries']})
(base/'measurements.json').write_text(json.dumps(report,indent=2)+'\n')
for role,row in report.items():print(role,json.dumps(row['delta']))
