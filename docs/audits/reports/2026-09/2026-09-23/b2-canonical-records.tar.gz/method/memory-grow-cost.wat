(module
  (import "ic0" "performance_counter" (func $counter (param i32) (result i64)))
  (import "ic0" "msg_reply_data_append" (func $append (param i32 i32)))
  (import "ic0" "msg_reply" (func $reply))
  (memory 2)
  (func $measure (param $pages i32) (local $start i64) (local $cost i64)
    i32.const 0
    call $counter
    local.set $start
    local.get $pages
    memory.grow
    drop
    i32.const 0
    call $counter
    local.get $start
    i64.sub
    local.set $cost
    i32.const 0
    i64.const 33778097996450116
    i64.store
    i32.const 7
    local.get $cost
    i64.store
    i32.const 0
    i32.const 15
    call $append
    call $reply)
  (func (export "canister_query grow_zero") i32.const 0 call $measure)
  (func (export "canister_query grow_one") i32.const 1 call $measure)
  (func (export "canister_query grow_two") i32.const 2 call $measure)
  (func $touch (param $pages i32) (local $start i64) (local $index i32) (local $cost i64)
    i32.const 0 call $counter local.set $start
    block $done
      loop $next
        local.get $index local.get $pages i32.ge_u br_if $done
        local.get $index i32.const 4096 i32.mul i32.const 1 i32.store
        local.get $index i32.const 1 i32.add local.set $index
        br $next
      end
    end
    i32.const 0 call $counter local.get $start i64.sub local.set $cost
    i32.const 0 i64.const 33778097996450116 i64.store
    i32.const 7 local.get $cost i64.store
    i32.const 0 i32.const 15 call $append call $reply)
  (func (export "canister_query touch_zero") i32.const 0 call $touch)
  (func (export "canister_query touch_one") i32.const 1 call $touch)
  (func (export "canister_query touch_two") i32.const 2 call $touch)
)
