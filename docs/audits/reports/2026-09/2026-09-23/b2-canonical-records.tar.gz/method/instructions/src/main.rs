use candid::{
    CandidType, Deserialize, Principal, decode_args, decode_one, encode_args, encode_one,
};
use canic_core::dto::{
    error::Error,
    metrics::{MetricEntry, MetricValue, MetricsKind},
    page::{Page, PageRequest},
    role::MetricsStatusRequest,
};
use ic_testkit::pic::{PocketIc, PocketIcBuilder, PocketIcBuilderExt, PocketIcStartupConfig};
use serde::Serialize;
use std::{fs, path::PathBuf, time::Duration};

#[derive(CandidType)]
enum StatusRequest {
    Metrics(MetricsStatusRequest),
}
#[derive(CandidType, Deserialize)]
enum StatusResponse {
    Metrics(Page<MetricEntry>),
}
#[derive(CandidType, Debug, Deserialize)]
struct HistoryCost {
    instructions: u64,
    points: u64,
    total: u64,
    reserved_bytes: u64,
    values_valid: bool,
}
#[derive(Serialize)]
struct Sample {
    condition: String,
    rows: u16,
    lifecycle: String,
    access: u8,
    callback_instructions: u64,
    export_instructions: u64,
    endpoint_instructions: u64,
    query_instructions: u64,
    history_points: u64,
    history_reserved_bytes: u64,
}

#[derive(Serialize)]
struct LifecycleSample {
    condition: String,
    rows: u16,
    lifecycle: String,
    export_instructions: u64,
}

fn export_cost(pic: &PocketIc, id: Principal, expected_stage: u64) -> u64 {
    let bytes = pic
        .query_call(
            id,
            Principal::anonymous(),
            "canic_b2_instruction_cost",
            encode_args(()).unwrap(),
        )
        .unwrap();
    let (stage, cost): (u64, u64) = decode_args(&bytes).unwrap();
    assert_eq!(stage, expected_stage);
    assert!(cost > 0);
    cost
}

fn endpoint_cost(pic: &PocketIc, id: Principal) -> (u64, u64) {
    let bytes = pic
        .query_call(
            id,
            Principal::anonymous(),
            "canic_observability",
            encode_one(StatusRequest::Metrics(MetricsStatusRequest {
                kind: MetricsKind::Runtime,
                page: PageRequest {
                    offset: 0,
                    limit: 5000,
                },
            }))
            .unwrap(),
        )
        .unwrap();
    let response: Result<StatusResponse, Error> = decode_one(&bytes).unwrap();
    let StatusResponse::Metrics(page) = response.unwrap();
    assert_eq!(
        page.entries.len() as u64,
        page.total,
        "complete metrics page"
    );
    page.entries
        .iter()
        .find_map(|entry| {
            if entry.labels
                == [
                    "perf",
                    "endpoint",
                    "update",
                    "qualify_history_sampling_cost",
                ]
            {
                let MetricValue::CountAndU64 { count, value_u64 } = entry.value else {
                    panic!("counter type")
                };
                Some((count, value_u64))
            } else {
                None
            }
        })
        .unwrap_or((0, 0))
}

fn main() {
    let base = PathBuf::from(std::env::args().nth(1).expect("measurement root"));
    let binary = PathBuf::from(std::env::args().nth(2).expect("pinned PocketIC binary"));
    let server = PocketIcStartupConfig::spawn(binary, Duration::from_secs(30))
        .start_managed_server()
        .expect("start owned server");
    let selected = std::env::args().nth(3).unwrap_or_else(|| "both".into());
    assert!(["before", "after", "both"].contains(&selected.as_str()));
    let mut expected_id = None;
    let mut samples = Vec::new();
    let mut lifecycle_samples = Vec::new();
    for condition in ["before", "after"] {
        if selected != "both" && selected != condition {
            continue;
        }
        let wasm = fs::read(base.join(format!(
            "results/{condition}/runtime_probe/instruction-wrapped.wasm"
        )))
        .unwrap();
        for rows in [1_u16, 211, 256] {
            let pic = PocketIcBuilder::new()
                .with_application_subnet()
                .try_build(PocketIcStartupConfig::connect(
                    server.url(),
                    Duration::from_secs(30),
                ))
                .unwrap();
            pic.set_time((std::time::UNIX_EPOCH + Duration::from_secs(1_800_000_001)).into());
            let id = pic.create_canister();
            if let Some(expected) = expected_id {
                assert_eq!(id, expected);
            } else {
                expected_id = Some(id);
            }
            pic.add_cycles(id, 10_000_000_000_000);
            pic.install_canister(id, wasm.clone(), encode_one(None::<Vec<u8>>).unwrap(), None);
            for lifecycle in ["install", "same_wasm_restore"] {
                if lifecycle == "same_wasm_restore" {
                    pic.upgrade_canister(id, wasm.clone(), encode_args(()).unwrap(), None)
                        .unwrap();
                }
                lifecycle_samples.push(LifecycleSample {
                    condition: condition.into(),
                    rows,
                    lifecycle: lifecycle.into(),
                    export_instructions: export_cost(
                        &pic,
                        id,
                        if lifecycle == "install" { 0 } else { 1 },
                    ),
                });
                println!(
                    "{}",
                    serde_json::to_string(lifecycle_samples.last().unwrap()).unwrap()
                );
                // Query execution cannot warm the persisted update heap. Sample starts
                // before the first explicit provider/history operation on each fresh heap.
                let mut previous = endpoint_cost(&pic, id);
                for access in 0..2_u8 {
                    let bytes = pic
                        .update_call(
                            id,
                            Principal::anonymous(),
                            "qualify_history_sampling_cost",
                            encode_one(rows).unwrap(),
                        )
                        .unwrap();
                    let result: Result<u64, Error> = decode_one(&bytes).unwrap();
                    let callback_instructions = result.unwrap();
                    let export_instructions = export_cost(&pic, id, 2);
                    let current = endpoint_cost(&pic, id);
                    assert_eq!(current.0, previous.0 + 1);
                    let endpoint_instructions = current.1.checked_sub(previous.1).unwrap();
                    assert!(
                        callback_instructions > 0 && endpoint_instructions >= callback_instructions
                    );
                    assert!(export_instructions >= endpoint_instructions);
                    previous = current;
                    let bytes = pic
                        .query_call(
                            id,
                            Principal::anonymous(),
                            "qualify_history_query_cost",
                            encode_one(288_u64).unwrap(),
                        )
                        .unwrap();
                    let result: Result<HistoryCost, Error> = decode_one(&bytes).unwrap();
                    let cost = result.unwrap();
                    assert!(cost.values_valid && cost.points > 0 && cost.points == cost.total);
                    assert!(cost.instructions > 0 && cost.reserved_bytes <= 8 * 1024 * 1024);
                    samples.push(Sample {
                        condition: condition.into(),
                        rows,
                        lifecycle: lifecycle.into(),
                        access,
                        callback_instructions,
                        export_instructions,
                        endpoint_instructions,
                        query_instructions: cost.instructions,
                        history_points: cost.points,
                        history_reserved_bytes: cost.reserved_bytes,
                    });
                    println!(
                        "{}",
                        serde_json::to_string(samples.last().unwrap()).unwrap()
                    );
                }
            }
        }
    }
    fs::write(
        base.join(format!("instruction-samples-{selected}.json")),
        serde_json::to_vec_pretty(
            &serde_json::json!({"samples":samples,"lifecycle":lifecycle_samples}),
        )
        .unwrap(),
    )
    .unwrap();
}
