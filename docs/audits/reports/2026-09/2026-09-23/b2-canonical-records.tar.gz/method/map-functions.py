from pathlib import Path
import re, json, hashlib, collections
import sys
root=Path(sys.argv[1])

def parse(path):
 s=path.read_text(); types={int(i):sig for i,sig in re.findall(r'^  \(type \(;(\d+);\) (.*)\)$',s,re.M)}
 def normalize(s):
  s=re.sub(r'\(;.*?;\)', '',s)
  s=re.sub(r'\(type (\d+)\)',lambda m:'(signature '+types[int(m[1])]+')',s)
  return ' '.join(s.split())
 fs={}; imp={}
 for line in s.splitlines():
  m=re.match(r'  \(import (.*)\(func \(;(\d+);\) (.*)\)\)',line)
  if m: imp[int(m[2])]=normalize(m[1]+m[3])
 starts=list(re.finditer(r'^  \(func \(;(\d+);\)',s,re.M))
 for ix,m in enumerate(starts):
  end=starts[ix+1].start() if ix+1<len(starts) else re.search(r'^  \((?:table|memory|global|export|elem|data) ',s[m.end():],re.M).start()+m.end()
  body=normalize(s[m.end():end]); calls=[int(i) for i in re.findall(r'\b(?:call|return_call|ref.func) (\d+)',body)]
  norm=re.sub(r'\b(call|return_call|ref.func) \d+',r'\1 TARGET',body)
  fs[int(m[1])]=(norm,calls)
 return fs,imp

n,ni=parse(root/'named.wat');c,ci=parse(root/'canonical.wat');inv=collections.defaultdict(set)
for i,(sig,_) in c.items():inv[sig].add(i)
candidates={i:set(inv[sig]) for i,(sig,_) in n.items()}
for i,sig in ni.items():candidates[i]={j for j,t in ci.items() if t==sig}
iterations=0;changed=True
while changed:
 changed=False;iterations+=1
 for i,(_,calls) in n.items():
  old=candidates[i];new={j for j in old if len(c[j][1])==len(calls) and all(ct in candidates.get(nt,set()) for nt,ct in zip(calls,c[j][1]))}
  if new!=old:candidates[i]=new;changed=True
print('functions',len(n),len(c),'matched',sum(bool(v) for v in candidates.values()),'unique',sum(len(v)==1 for v in candidates.values()),'iterations',iterations)
(root/'canonical-function-map.json').write_text(json.dumps({str(i):sorted(v) for i,v in candidates.items()},indent=2)+'\n')
