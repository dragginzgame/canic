#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
for condition in before after; do
    while IFS=$'\t' read -r id role; do
        capture="$base/results/$condition/$id"
        [[ -s "$capture/role-build-output.txt" ]] || continue
        if [[ ! -s "$capture/canonical-bijection.json" ]]; then
            printf 'tracing %s %s\n' "$condition" "$id"
            bash "$base/trace.sh" "$condition" "$id" "$role" > "$capture/trace.log" 2>&1
        fi
        python3 "$base/extract-bodies.py" "$capture" "$role" > "$capture/body-extraction.log"
        printf 'verified %s %s\n' "$condition" "$id"
    done < <(python3 - "$base/artifacts.json" <<'PY'
import json,sys
for row in json.load(open(sys.argv[1])):print(row['id'],row['role'],sep='\t')
PY
    )
done
