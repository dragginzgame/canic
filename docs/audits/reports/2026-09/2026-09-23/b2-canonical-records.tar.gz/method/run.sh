#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$base"
export ICP_ENVIRONMENT=local CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0 RUSTC_WRAPPER=''
cargo metadata --offline --format-version 1 --manifest-path harness/Cargo.toml > harness-metadata.json
cp harness/Cargo.lock harness-Cargo.lock
rustc --edition 2024 -D warnings -C debuginfo=0 -C strip=symbols wasm-replica-function-count.rs -o wasm-replica-function-count
for condition in before after; do
    tar -xzf "$condition.tar.gz" -C product
    while IFS= read -r path; do touch "product/$path"; done < changed-paths.txt
    mkdir -p "results/$condition"
    CARGO_TARGET_DIR="$base/driver-target" cargo build --offline --locked --profile fast \
        --manifest-path harness/Cargo.toml > "results/$condition/driver.log" 2>&1
    cp driver-target/fast/canic-b2-canonical-build "results/$condition/driver"
    for role in app test; do
        destination="$base/results/$condition/$role"
        mkdir -p "$destination"
        printf 'building %s %s\n' "$condition" "$role"
        (
            cd "$base/product"
            CARGO_TARGET_DIR="$base/artifact-target" RUSTC_WRAPPER="$base/capture-rustc.sh" \
                B2_CAPTURE_CRATE="canister_$role" B2_CAPTURE_DIR="$destination" \
                "$base/results/$condition/driver" "$role" release "$base/product" "$base/product" \
                "$base/product/apps/test/canic.toml" "$destination/transforms.json"
        ) > "$destination/build.log" 2>&1
        for extension in wasm wasm.gz did; do
            cp "product/.icp/local/canisters/$role/$role.$extension" "$destination/$role.$extension"
        done
        [[ -s "$destination/raw.wasm" && -s "$destination/link-map.txt" ]]
        wasm-validate "$destination/$role.wasm"
        didc check "$destination/$role.did" > "$destination/did-check.txt"
        "$base/wasm-replica-function-count" "$destination/$role.wasm" > "$destination/defined-functions.txt"
        wasm-objdump -x "$destination/$role.wasm" > "$destination/sections.txt"
        ic-wasm "$destination/$role.wasm" info > "$destination/ic-wasm-info.txt"
        printf 'completed %s %s\n' "$condition" "$role"
    done
    mv artifact-target "artifact-target-$condition"
done
cmp harness/Cargo.lock harness-Cargo.lock
