#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$base"
export ICP_ENVIRONMENT=local CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0 RUSTC_WRAPPER=''
for condition in before after; do
    python3 switch-source.py "$condition"
    if [[ ! -e artifact-target ]]; then mv "artifact-target-$condition" artifact-target; fi
    while IFS=$'\t' read -r id role package config; do
        destination="$base/results/$condition/$id"
        [[ ! -f "$destination/role-build-output.txt" ]] || continue
        mkdir -p "$destination"
        crate="${package//-/_}"
        case "$id" in
            fleet_coordinator) crate=canister_fleet_coordinator ;;
            wasm_store) crate=canister_wasm_store ;;
        esac
        printf 'building %s %s\n' "$condition" "$id"
        (
            cd "$base/product"
            CARGO_TARGET_DIR="$base/artifact-target" RUSTC_WRAPPER="$base/capture-rustc.sh" \
                B2_CAPTURE_CRATE="$crate" B2_CAPTURE_DIR="$destination" \
                "$base/results/$condition/driver" "$role" release "$base/product" "$base/product" \
                "$base/product/$config" "$destination/transforms.json"
        ) > "$destination/build.log" 2>&1
        for extension in wasm wasm.gz did; do
            cp "product/.icp/local/canisters/$role/$role.$extension" "$destination/$role.$extension"
        done
        [[ -s "$destination/raw.wasm" && -s "$destination/link-map.txt" ]]
        wasm-validate "$destination/$role.wasm"
        didc check "$destination/$role.did" > "$destination/did-check.txt"
        "$base/wasm-replica-function-count" "$destination/$role.wasm" > "$destination/defined-functions.txt"
        wasm-objdump -x "$destination/$role.wasm" > "$destination/sections.txt"
        ic-wasm "$destination/$role.wasm" info > "$destination/ic-wasm-info.txt"
        python3 - "$base" "$destination" "$package" <<'PY'
from pathlib import Path
import sys
base,destination,package=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
outputs=list((base/'artifact-target'/'wasm32-unknown-unknown'/'release'/'build').glob(f'{package}-*/output'))
generated=base/'product/apps/test/.canic/generated'/package/'Cargo.toml'
if generated.exists():
 (destination/'generated-Cargo.toml').write_bytes(generated.read_bytes())
if package=='canic-fleet-coordinator':
 assert not outputs,(package,outputs)
 (destination/'role-build-output.txt').write_text(f'canic_static_wrapper={package}\n')
else:
 assert len(outputs)==1,(package,outputs)
 (destination/'role-build-output.txt').write_bytes(outputs[0].read_bytes())
PY
        printf 'completed %s %s\n' "$condition" "$id"
    done < remaining.tsv
    mv artifact-target "artifact-target-$condition"
done
