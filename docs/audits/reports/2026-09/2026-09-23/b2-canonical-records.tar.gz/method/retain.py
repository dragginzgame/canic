from pathlib import Path
import hashlib,json,tarfile,io,gzip

base=Path(__file__).resolve().parent
repo=base.parent.parent
out=repo/'docs/audits/reports/2026-09/2026-09-23'
measurements=json.loads((base/'measurements.json').read_text())
inventory=json.loads((base/'artifacts.json').read_text())
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
records={}
for artifact_id,row in measurements.items():
    records[artifact_id]={}
    for condition in ['before','after']:
        root=base/'results'/condition/artifact_id
        record=json.loads((root/'canonical-storage-bodies.json').read_text())
        assert record['canonical_sha256']==row[condition]['sha256']
        witness=json.loads((root/'canonical-bijection.json').read_text())
        assert witness['all_calls_preserved'] and witness['all_export_table_import_bindings_preserved']
        records[artifact_id][condition]={
            'all_functions_bijective':record['all_functions_bijective'],
            'raw_link_coverage':{key:value for key,value in json.loads((root/'link-name-map.json').read_text()).items() if key in ['defined_functions','named_functions','raw_sha256']},
            'non_code_sections_exact':record['non_code_sections_exact'],
            'named_family_body_counts':{name:len(bodies) for name,bodies in record['selected_families'].items()},
            'evidence_sha256':{p.name:digest(p) for p in root.iterdir() if p.is_file()},
        }

method_names=['artifacts.json','source-manifest.json','changed-paths.txt','tools.json','run.sh',
    'extend.sh','remaining.tsv','remaining-before.tsv','remaining-after.tsv','capture-rustc-prefix.sh','capture-rustc.sh','switch-source.py','summarize.py','wasm_metrics.py',
    'wasm-replica-function-count.rs','trace.sh','trace-ready.sh','attach-link-names.py',
    'map-functions.py','verify-map.py','verify-map-exhaustive.py','extract-bodies.py',
    'trace-controls.json','retain.py','harness/Cargo.toml','harness/src/main.rs','harness-Cargo.lock',
    'wrap-instructions.py','instructions/Cargo.toml','instructions/Cargo.lock','instructions/src/main.rs',
    'instruction-lock-differences.json','instruction-build.log','instruction-comparison.json',
    'instruction-samples-before.json','instruction-samples-after.json','instruction-samples-both.json',
    'instructions-before.log','instructions-after.log','instructions-repeat.log',
    'instructions/src/bin/grow.rs','memory-grow-cost.wat','memory-grow-cost.json','memory-grow-cost.log','grow-build.log']
members={f'method/{name}':base/name for name in method_names}
for artifact_id,row in records.items():
    for condition in row:
        root=base/'results'/condition/artifact_id
        for path in root.iterdir():
            if path.suffix in ['.json','.log','.txt','.did'] or path.name=='generated-Cargo.toml':
                # Full section text repeats large data payloads; hashes remain in the report.
                if path.name in ['sections.txt','link-map.txt','link-name-map.json']:continue
                members[f'{condition}/{artifact_id}/{path.name}']=path
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
    for name,path in sorted(members.items()):
        data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
        archive.addfile(info,io.BytesIO(data))
bundle=out/'b2-canonical-records.tar.gz'
bundle.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
report={
    'schema_version':1,'date':'2026-09-23','scope':'B2 cumulative canonical footprint checkpoint',
    'complete_b2':False,'build_speed_claim':False,'clean_repeat_claim':False,
    'expected_artifacts':[r['id'] for r in inventory],'measured_artifacts':list(measurements),
    'source_archives':{condition:{'path':str((base/f'{condition}.tar.gz').relative_to(repo)),
        'sha256':digest(base/f'{condition}.tar.gz')} for condition in ['before','after']},
    'source_manifest_sha256':digest(base/'source-manifest.json'),
    'source_files':1994,'changed_source_files':48,
    'tools':json.loads((base/'tools.json').read_text()),
    'frozen_limits':{'code_bytes':10485760,'defined_functions':50000,'total_module_bytes':104857600,
        'required_code_reserve_bytes':524288,'required_function_reserve':2500},
    'measurements':measurements,'canonical_traces':records,
    'trace_controls':json.loads((base/'trace-controls.json').read_text()),
    'retained_records':{'file':bundle.name,'sha256':digest(bundle),'members':len(members)},
    'instructions':json.loads((base/'instruction-comparison.json').read_text()),
    'limitations':['One build per condition; no independent clean repetition.',
        'Named absence alone does not prove absence of inlined code.',
        'Frozen source archives and raw Wasm remain in local measurement storage.',
        'Runtime sampling measurements pass; two exact chart-query subspans exceed 1% and remain unresolved.',
        'B2 remains active; no B3 decision or release qualification follows.'],
    'excluded_attempts':[
        'Initial native driver compilation referenced the removed ToolUnavailable enum variant; corrected before artifact measurement.',
        'Initial Coordinator build used a package-name capture selector instead of its library name; corrected capture reproduces identical canonical bytes.',
        'Initial Root bijection search timed out; constraint propagation now verifies every body, call and binding.',
        'WAT conversion omitted DataCount in the first instruction wrapper attempt; original metadata is now restored and no failed artifact was executed.',
        'Store selection capture initially assumed no build script; its actual output was retained without repeating the build.',
        'Initial scale-replica declaration compiled but capture matched the scale-hub filename prefix; exact output selection corrected the measurement wrapper.']
}
(out/'b2-canonical-measurements.json').write_text(json.dumps(report,indent=2)+'\n')
print('retained',len(measurements),'pairs;',len(members),'records;',bundle.stat().st_size,'compressed bytes')
