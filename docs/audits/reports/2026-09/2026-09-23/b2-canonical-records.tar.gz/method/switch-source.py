from pathlib import Path
import tarfile,sys,json,hashlib
base=Path(__file__).resolve().parent
condition=sys.argv[1]
with tarfile.open(base/f'{condition}.tar.gz') as archive:
 for member in archive.getmembers():
  if not member.isfile():continue
  data=archive.extractfile(member).read();path=base/'product'/member.name
  if not path.exists() or path.read_bytes()!=data:
   path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data);path.chmod(member.mode)
for row in json.loads((base/'source-manifest.json').read_text()):
 assert hashlib.sha256((base/'product'/row['path']).read_bytes()).hexdigest()==row[f'{condition}_sha256'],row['path']
print('source verified',condition)
