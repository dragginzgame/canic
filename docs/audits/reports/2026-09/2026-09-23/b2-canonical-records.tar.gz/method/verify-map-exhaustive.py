from pathlib import Path
import json,re,itertools,hashlib,subprocess
import sys
root=Path(sys.argv[1])
exec(Path(__file__).with_name('map-functions.py').read_text().split('n,ni=parse')[0])
n,ni=parse(root/'named.wat');c,ci=parse(root/'canonical.wat');candidates={int(k):v for k,v in json.loads((root/'canonical-function-map.json').read_text()).items()}
wat=(root/'named.wat').read_text();anchors={int(i) for i in re.findall(r'^  \(export .*?\(func (\d+)\)',wat,re.M)}
for line in wat.splitlines():
 if line.startswith('  (elem '):
  m=re.search(r' func ([\d ]+)\)',line);assert m;anchors.update(map(int,m[1].split()))
anchors.update(ni)
fixed={i:v[0] for i,v in candidates.items() if len(v)==1};ambiguous={i:v for i,v in candidates.items() if len(v)>1};keys=list(ambiguous)
for values in itertools.product(*(ambiguous[i] for i in keys)):
 mapping=fixed|dict(zip(keys,values))
 if len(set(mapping.values()))!=len(mapping):continue
 if any(mapping[i]!=i for i in anchors):continue
 if any(mapping[nc]!=cc for i,(_,calls) in n.items() for nc,cc in zip(calls,c[mapping[i]][1])):continue
 break
else:raise AssertionError('no complete reference-preserving bijection')
assert len(mapping)==len(n)+len(ni)==len(c)+len(ci)
# All signatures/non-reference instructions were checked by the candidate map;
# this witness additionally checks every call target and export/table/import root.
(root/'canonical-bijection.json').write_text(json.dumps({'all_functions':len(mapping),'anchors':len(anchors),'bijection':mapping,'all_calls_preserved':True,'all_export_table_import_bindings_preserved':True},indent=2)+'\n')
print('complete bijection',len(mapping),'anchors',len(anchors))
