from pathlib import Path
import sys,re,subprocess
sys.path.insert(0,str(Path('.tmp/b2-canonical-20260923').resolve()))
from wasm_metrics import var
base=Path('.tmp/b2-canonical-20260923');out=Path('.tmp/b2-query-20260923')
def leb(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return b
for label,indices in {'name':(3008,2987),'enabled':(1293,1276),'malloc':(108,108)}.items():
 if len(sys.argv)>1 and label!=sys.argv[1]:continue
 for condition,target in zip(['before','after'],indices):
  src=base/'results'/condition/'runtime_probe';wat=(src/'instruction-wrapped.wat').read_text();data=(src/'instruction-wrapped.wasm').read_bytes()
  funcs=[int(i) for i in re.findall(r'\(func \(;(\d+);\)',wat)];nf=max(funcs)+1
  ng=max(int(i) for i in re.findall(r'\(global \(;(\d+);\)',wat))+1
  perf=int(re.search(r'\(import "ic0" "performance_counter" \(func \(;(\d+);\)',wat)[1]);query=int(re.search(r'\(export "canister_query qualify_history_query_cost" \(func (\d+)\)\)',wat)[1])
  header=re.search(r'^  \(func \(;'+str(target)+r';\)[^\n]+',wat,re.M)[0];params=re.search(r'\(param ([^)]+)\)',header);params=params[1].split() if params else [];result=re.search(r'\(result ([^)]+)\)',header);result=result[1].split() if result else []
  assert all(x=='i32' for x in params) and len(result)<=1,(label,header)
  wat=re.sub(r'\bcall '+str(target)+r'\b','call '+str(nf),wat)
  wat=re.sub(r'\bcall '+str(perf)+r'\b','call '+str(nf+1),wat)
  wat=wat.replace(f'(export "canister_query qualify_history_query_cost" (func {query}))',f'(export "canister_query qualify_history_query_cost" (func {nf+2}))')
  args='\n'.join(f'local.get {i}' for i in range(len(params)));sig=' '.join(['(param '+' '.join(params)+')'] if params else []);res='(result '+result[0]+')' if result else '';saved=len(params)+1
  wrap=f'''(global (mut i32) (i32.const 0))
(global (mut i64) (i64.const 0))
(func {sig} {res} (local i64) {'(local '+result[0]+')' if result else ''}
 global.get {ng}
 if {res}
 i32.const 0
 call {perf}
 local.set {len(params)}
 {args}
 call {target}
 {'local.set '+str(saved) if result else ''}
 global.get {ng+1}
 i32.const 0
 call {perf}
 local.get {len(params)}
 i64.sub
 i64.add
 global.set {ng+1}
 {'local.get '+str(saved) if result else ''}
 else
 {args}
 call {target}
 end)
(func (param i32) (result i64)
 global.get {ng}
 if (result i64)
 global.get {ng+1}
 else
 local.get 0
 call {perf}
 end)
(func
 i32.const 1
 global.set {ng}
 i64.const 0
 global.set {ng+1}
 call {query})'''
  dest=out/f'attribute-{label}'/'results'/condition/'runtime_probe';dest.mkdir(parents=True,exist_ok=True)
  w=dest/'attribute.wat';w.write_text(wat.rstrip()[:-1]+'\n'+wrap+'\n)\n');binary=dest/'instruction-wrapped.wasm'
  subprocess.run(['wat2wasm',str(w),'-o',str(binary)],check=True)
  original={};custom=[];p=8
  while p<len(data):
   kind=data[p];size,start=var(data,p+1);end=start+size
   if kind:original[kind]=data[start:end]
   else:custom.append(data[p:end])
   p=end
  b=binary.read_bytes();p=8
  while b[p]!=10:size,start=var(b,p+1);p=start+size
  if 12 in original:b=b[:p]+bytes([12])+leb(len(original[12]))+original[12]+b[p:]
  binary.write_bytes(b+b''.join(custom));subprocess.run(['wasm-validate',str(binary)],check=True)
  print(label,condition,target,header)
