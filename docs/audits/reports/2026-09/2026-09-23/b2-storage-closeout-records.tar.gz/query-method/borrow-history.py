from pathlib import Path
root=Path('.tmp/b2-canonical-20260923/product');backup=Path('.tmp/b2-query-20260923/history-originals')
files=['crates/canic-core/src/view/public_metrics/mod.rs','crates/canic-core/src/model/public_metrics/history/mod.rs','crates/canic-core/src/ops/runtime/public_metrics/mod.rs']
for name in files:
 b=backup/name;b.parent.mkdir(parents=True,exist_ok=True)
 if not b.exists():b.write_bytes((root/name).read_bytes())
p=root/files[0];s=p.read_text().replace('use crate::model::public_metrics::PublicHistorySample;','use crate::model::public_metrics::{PublicHistorySample, PUBLIC_HISTORY_SLOTS};')
s+='''
/// Borrowed history rows, visited in chronological order without a scratch allocation.
pub struct PublicHistorySeriesReader<'a> {
    pub unit: &'a str,
    pub samples: PublicHistorySamples<'a>,
}

/// Sparse chronological traversal of one position in a grouped history ring.
pub struct PublicHistorySamples<'a> {
    rows: &'a [[PublicHistorySample; 8]],
    valid: &'a [u64],
    position: usize,
    latest_slot: u64,
    ranges: [std::ops::Range<usize>; 2],
    range: usize,
}

impl<'a> PublicHistorySamples<'a> {
    pub(crate) const fn new(
        rows: &'a [[PublicHistorySample; 8]],
        valid: &'a [u64],
        position: usize,
        latest_slot: u64,
        split: usize,
    ) -> Self {
        Self {
            rows, valid, position, latest_slot,
            ranges: [split..PUBLIC_HISTORY_SLOTS, 0..split],
            range: 0,
        }
    }
}

impl Iterator for PublicHistorySamples<'_> {
    type Item = PublicHistorySample;

    fn next(&mut self) -> Option<Self::Item> {
        while let Some(range) = self.ranges.get_mut(self.range) {
            if range.is_empty() {
                self.range += 1;
                continue;
            }
            let word = range.start / 64;
            let end = range.end.min((word + 1) * 64);
            let bits = self.valid[word]
                & (u64::MAX << (range.start % 64))
                & (u64::MAX >> (63 - (end - 1) % 64));
            if bits == 0 {
                range.start = end;
                continue;
            }
            let physical = word * 64 + bits.trailing_zeros() as usize;
            range.start = physical + 1;
            let point = self.rows[physical][self.position];
            if self.latest_slot.saturating_sub(point.slot) < PUBLIC_HISTORY_SLOTS as u64 {
                return Some(point);
            }
        }
        None
    }
}
''';p.write_text(s)
p=root/files[1];s=p.read_text().replace('view::public_metrics::PublicHistorySeries,','view::public_metrics::{PublicHistorySeriesReader, PublicHistorySamples},');s=s.replace('    fn project(&self, series: &StoredSeries) -> PublicHistorySeries {','    #[cfg(test)]\n    fn project(&self, series: &StoredSeries) -> crate::view::public_metrics::PublicHistorySeries {').replace('        PublicHistorySeries {','        crate::view::public_metrics::PublicHistorySeries {',1).replace('    fn append_range(','    #[cfg(test)]\n    fn append_range(',1)
a=s.index('    #[must_use]\n    pub fn series(');b=s.index('    #[must_use]\n    pub fn heap_started_at_ns',a)
s=s[:a]+'''    /// Project one series while its immutable history borrow remains live.
    pub fn with_series<R>(
        family: PublicMetricFamily,
        name: String,
        canister_id: Option<Principal>,
        project: impl FnOnce(PublicHistorySeriesReader<'_>) -> R,
    ) -> Option<R> {
        HISTORY.with_borrow(|history| {
            let series = history.series.get(&SeriesKey { family, name, canister_id })?;
            let group = history.groups[series.group].as_ref().unwrap();
            let latest_slot = series.latest_observed_at_ns / PUBLIC_METRICS_CADENCE_NS;
            let window = PUBLIC_HISTORY_SLOTS as u64;
            let split = usize::try_from((latest_slot % window + 1 + window - group.origin % window) % window)
                .expect("history slot is below 288");
            Some(project(PublicHistorySeriesReader {
                unit: &series.unit,
                samples: PublicHistorySamples::new(&group.rows, &series.valid, series.position, latest_slot, split),
            }))
        })
    }

    #[cfg(test)]
    pub fn series(
        family: PublicMetricFamily,
        name: String,
        canister_id: Option<Principal>,
    ) -> Option<crate::view::public_metrics::PublicHistorySeries> {
        Self::with_series(family, name, canister_id, |series| crate::view::public_metrics::PublicHistorySeries {
            unit: series.unit.to_owned(),
            slots: series.samples.collect(),
        })
    }

'''+s[b:];p.write_text(s)
p=root/files[2];s=p.read_text();a=s.index('        let series = (selected && valid_name)');b=s.index('        PublicHistorySnapshot {',a)
s=s[:a]+'''        let slot = now_ns / PUBLIC_METRICS_CADENCE_NS;
        let mut entries = Vec::new();
        let mut previous = None;
        let mut coverage_start_ns = None;
        let mut total = 0_u64;
        let unit = (selected && valid_name).then(|| {
            PublicHistoryCache::with_series(request.family, request.name, request.canister_id, |series| {
                for point in series.samples {
                    if point.slot > slot || slot - point.slot >= PUBLIC_HISTORY_SLOTS as u64 {
                        continue;
                    }
                    coverage_start_ns.get_or_insert(point.slot * PUBLIC_METRICS_CADENCE_NS);
                    if total >= request.page.offset && entries.len() as u64 < request.page.limit.min(PUBLIC_HISTORY_SLOTS as u64) {
                        entries.push(PublicHistoryPoint {
                            delta: previous.as_ref().and_then(|previous| counter_delta(previous, &point)),
                            slot_start_ns: point.slot * PUBLIC_METRICS_CADENCE_NS,
                            observed_at_ns: point.observed_at_ns,
                            value: point.value,
                            kind: point.kind,
                        });
                    }
                    total += 1;
                    previous = Some(point);
                }
                series.unit.to_owned()
            })
        }).flatten();
        let state = if !selected {
            PublicSnapshotState::Disabled
        } else if let Some(point) = previous {
            if now_ns.saturating_sub(point.observed_at_ns) > PUBLIC_METRICS_STALE_AFTER_NS {
                PublicSnapshotState::Stale
            } else {
                PublicSnapshotState::Fresh
            }
        } else {
            PublicSnapshotState::Unavailable
        };
'''+s[b:];p.write_text(s)
