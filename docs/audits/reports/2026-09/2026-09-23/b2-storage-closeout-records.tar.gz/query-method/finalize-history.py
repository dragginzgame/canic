from pathlib import Path
root=Path('.tmp/b2-canonical-20260923/product')
p=root/'crates/canic-core/src/model/public_metrics/mod.rs';s=p.read_text().replace('/// Maximum rows retained per family', '/// Adjacent series positions in one history allocation.\npub(crate) const PUBLIC_HISTORY_GROUP_WIDTH: usize = 8;\n\n/// Maximum rows retained per family',1);p.write_text(s)
p=root/'crates/canic-core/src/model/public_metrics/history/mod.rs';s=p.read_text().replace('PUBLIC_METRICS_CADENCE_NS, PublicMetricSample','PUBLIC_METRICS_CADENCE_NS, PUBLIC_HISTORY_GROUP_WIDTH, PublicMetricSample').replace('const GROUP_WIDTH: usize = 8;','const GROUP_WIDTH: usize = PUBLIC_HISTORY_GROUP_WIDTH;')
a=s.index('    #[cfg(test)]\n    fn project(');b=s.index('\nstruct History {',a)
s=s[:a]+'''    fn reader<'a>(&'a self, series: &'a StoredSeries) -> PublicHistorySeriesReader<'a> {
        let latest_slot = series.latest_observed_at_ns / PUBLIC_METRICS_CADENCE_NS;
        let window = PUBLIC_HISTORY_SLOTS as u64;
        let split = usize::try_from((latest_slot % window + 1 + window - self.origin % window) % window)
            .expect("history slot is below 288");
        PublicHistorySeriesReader {
            unit: &series.unit,
            samples: PublicHistorySamples::new(&self.rows, &series.valid, series.position, latest_slot, split),
        }
    }

    #[cfg(test)]
    fn project(&self, series: &StoredSeries) -> crate::view::public_metrics::PublicHistorySeries {
        let reader = self.reader(series);
        crate::view::public_metrics::PublicHistorySeries {
            unit: reader.unit.to_owned(),
            slots: reader.samples.collect(),
        }
    }
}
''' +s[b:]
a=s.index('            let latest_slot =',s.index('    pub fn with_series'));b=s.index('\n        })',a);s=s[:a]+'''            Some(project(group.reader(series)))'''+s[b:];p.write_text(s)
p=root/'crates/canic-core/src/view/public_metrics/mod.rs';s=p.read_text().replace('PUBLIC_HISTORY_SLOTS, PublicHistorySample','PUBLIC_HISTORY_GROUP_WIDTH, PUBLIC_HISTORY_SLOTS, PublicHistorySample').replace('[PublicHistorySample; 8]','[PublicHistorySample; PUBLIC_HISTORY_GROUP_WIDTH]').replace('    range: usize,','    range: usize,\n    remaining: usize,').replace('pub(crate) const fn new(','pub(crate) fn new(').replace('            range: 0,','            range: 0,\n            remaining: valid.iter().map(|word| word.count_ones() as usize).sum(),').replace('            let point = self.rows[physical][self.position];','            self.remaining -= 1;\n            let point = self.rows[physical][self.position];').replace('        None\n    }\n}', '''        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        (0, Some(self.remaining))
    }
}''');p.write_text(s)
p=root/'crates/canic-core/src/ops/runtime/public_metrics/mod.rs';s=p.read_text().replace('                    for point in series.samples {','''                    let maximum = series.samples.size_hint().1.unwrap_or(PUBLIC_HISTORY_SLOTS);
                    let limit = usize::try_from(request.page.limit.min(PUBLIC_HISTORY_SLOTS as u64))
                        .unwrap_or(PUBLIC_HISTORY_SLOTS);
                    entries = Vec::with_capacity(maximum.min(limit));
                    for point in series.samples {''');p.write_text(s)
