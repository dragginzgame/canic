from pathlib import Path
import json,hashlib,difflib,subprocess
repo=Path.cwd();base=repo/'.tmp/b2-closeout-20260923';product=repo/'.tmp/b2-canonical-20260923/product'
manifest=json.loads((base/'source-manifest.json').read_text());overlays=[];patch=[]
allowed={'crates/canic-core/src/ops/runtime/metrics/tests.rs','crates/canic-core/src/workflow/metrics/query.rs'}
for row in manifest:
 name=row['path'];frozen=(product/name).read_bytes();current=(repo/name).read_bytes()
 assert hashlib.sha256(frozen).hexdigest()==row['after_sha256'],name
 if frozen==current:continue
 assert name in allowed,name
 old=frozen.decode();new=current.decode()
 expected=old.replace('"bootstrap"','"store"',1)
 formatted=subprocess.run(['rustfmt','--edition','2024','--emit','stdout'],input=expected,text=True,capture_output=True,check=True).stdout
 assert new in (expected,formatted),name
 if name.endswith('/query.rs'):
  boundary='#[cfg(test)]\nmod tests {'
  assert old.split(boundary)[0]==new.split(boundary)[0] and len(old.split(boundary))==2
 else:
  assert '#[cfg(test)]\nmod tests;' in (repo/'crates/canic-core/src/ops/runtime/metrics/mod.rs').read_text()
 overlays.append({'path':name,'build_source_sha256':row['after_sha256'],'qualified_native_source_sha256':hashlib.sha256(current).hexdigest(),'change':'expected Store metric label inside cfg(test) only'})
 patch.extend(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
assert len(overlays)==2
(base/'native-test-overlay.patch').write_text(''.join(patch));(base/'native-test-overlay.json').write_text(json.dumps(overlays,indent=2)+'\n')
print('source verified:',len(manifest),'isolated build files;',len(overlays),'native-only expected-label corrections; all production inputs exact')
