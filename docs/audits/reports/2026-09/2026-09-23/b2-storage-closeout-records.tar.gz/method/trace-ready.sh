#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
while IFS=$'\t' read -r id role package config; do
    root="$base/results/after/$id"
    until [[ -f "$root/role-build-output.txt" ]]; do sleep 5; done
    if [[ ! -f "$root/canonical-storage-bodies.json" ]]; then
        bash "$base/trace.sh" after "$id" "$role" > "$root/trace.log" 2>&1
        python3 "$base/extract-bodies.py" "$root" "$role" > "$root/body-extraction.log"
    fi
    echo "verified $id"
done < "$base/roster.tsv"
