from pathlib import Path
import hashlib,json,tarfile,re
repo=Path.cwd();out=repo/'docs/audits/reports/2026-09/2026-09-23'
r=json.loads((out/'b2-storage-closeout.json').read_text())
bundle=out/r['retained_records']['file']
assert hashlib.sha256(bundle.read_bytes()).hexdigest()==r['retained_records']['sha256']
with tarfile.open(bundle,'r:gz') as archive:
 names=archive.getnames();assert len(names)==len(set(names))==r['retained_records']['members']
 inventory=json.load(archive.extractfile('member-sha256.json'))
 assert set(inventory)==set(names)-{'member-sha256.json'}
 for name,digest in inventory.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,name
 manifest=json.load(archive.extractfile('method/source-manifest.json'))
 overlay={v['path']:v['qualified_native_source_sha256'] for v in r['native_only_overlay']}
 for entry in manifest:
  path=repo/entry['path'];assert hashlib.sha256(path.read_bytes()).hexdigest()==overlay.get(entry['path'],entry['after_sha256']),entry['path']
 assert {v['id'] for v in json.load(archive.extractfile('method/artifacts.json'))}==set(r['measurements'])
 for aid,m in r['measurements'].items():
  body=json.load(archive.extractfile(f'after/{aid}/canonical-storage-bodies.json'))
  assert body['canonical_sha256']==m['after']['sha256']
  assert body['defined_functions']==m['after']['defined_functions']
 for condition in ['before','after']:
  samples=json.load(archive.extractfile('method/full-query/instruction-samples-both.json'))
  assert any(x['condition']==condition for x in samples['samples'])
 cold=[v for v in r['instructions']['rows'] if v['full_query_instructions']['percent']>1]
 assert {(v['rows'],v['lifecycle'],v['access'],v['full_query_instructions']['delta']) for v in cold}=={(1,'same_wasm_restore',1,77421),(211,'install',1,77549),(256,'install',0,79858),(256,'install',1,80008)}
 assert r['instructions']['cold_query_exception_accepted'] and r['instructions']['all_sampling_within_one_percent']
 assert r['instructions']['cold_repeat_exact'] and r['instructions']['all_warm_controls_within_one_percent']
for filename in ['docs/audits/reports/2026-09/2026-09-23/b2-storage-closeout.md','docs/audits/working/0.110-fleet-runtime-contraction/b2-storage-reachability.md','docs/design/0.110-fleet-runtime-contraction/status.md','docs/design/0.110-fleet-runtime-contraction/0.110-design.md','docs/changelog/0.110.md','docs/status/current.md','CHANGELOG.md']:
 p=repo/filename
 # Only the edited current handoff, not the historical diary below it.
 source=p.read_text()
 if filename=='docs/status/current.md':source=source.split('## Completed-source external debit recovery')[0]
 if filename.endswith('/status.md'):source=source.split('## After .37')[0]
 for target in re.findall(r'\]\(([^\s)]+)\)',source):
  if '://' in target or target.startswith('#'):continue
  assert (p.parent/target.split('#')[0]).exists(),(filename,target)
print('verified bundle member hashes, source binding, artifact identities, exact accepted cases and current local links')
