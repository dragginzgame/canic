#!/usr/bin/env bash
set -euo pipefail
base="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
old="$(cd "$base/../b2-canonical-20260923" && pwd)"
export ICP_ENVIRONMENT=local CARGO_NET_OFFLINE=true CARGO_INCREMENTAL=0 RUSTC_WRAPPER=''
while IFS=$'\t' read -r id role package config; do
    destination="$base/results/after/$id"
    [[ ! -f "$destination/role-build-output.txt" ]] || continue
    mkdir -p "$destination"
    crate="${package//-/_}"
    case "$id" in fleet_coordinator) crate=canister_fleet_coordinator ;; wasm_store) crate=canister_wasm_store ;; esac
    echo "building $id"
    (
        cd "$old/product"
        CARGO_TARGET_DIR="$old/artifact-target-after" RUSTC_WRAPPER="$old/capture-rustc.sh" \
            B2_CAPTURE_CRATE="$crate" B2_CAPTURE_DIR="$destination" \
            "$old/results/after/driver" "$role" release "$old/product" "$old/product" \
            "$old/product/$config" "$destination/transforms.json"
    ) > "$destination/build.log" 2>&1
    for extension in wasm wasm.gz did; do
        cp "$old/product/.icp/local/canisters/$role/$role.$extension" "$destination/$role.$extension"
    done
    [[ -s "$destination/raw.wasm" && -s "$destination/link-map.txt" ]]
    wasm-validate "$destination/$role.wasm"
    didc check "$destination/$role.did" > "$destination/did-check.txt"
    "$base/wasm-replica-function-count" "$destination/$role.wasm" > "$destination/defined-functions.txt"
    ic-wasm "$destination/$role.wasm" info > "$destination/ic-wasm-info.txt"
    python3 - "$old" "$destination" "$package" <<'PY'
from pathlib import Path
import sys
old,destination,package=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
outputs=list((old/'artifact-target-after/wasm32-unknown-unknown/release/build').glob(f'{package}-*/output'))
generated=old/'product/apps/test/.canic/generated'/package/'Cargo.toml'
if generated.exists():(destination/'generated-Cargo.toml').write_bytes(generated.read_bytes())
if package=='canic-fleet-coordinator':
 assert not outputs
 (destination/'role-build-output.txt').write_text(f'canic_static_wrapper={package}\n')
else:
 assert len(outputs)==1,(package,outputs)
 (destination/'role-build-output.txt').write_bytes(outputs[0].read_bytes())
PY
    echo "completed $id"
done < "$base/roster.tsv"
python3 "$base/summarize.py"
