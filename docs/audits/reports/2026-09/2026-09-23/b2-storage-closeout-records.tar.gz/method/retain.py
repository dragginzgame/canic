from pathlib import Path
import hashlib,json,tarfile,io,gzip,subprocess
base=Path(__file__).resolve().parent;repo=base.parent.parent
old=repo/'.tmp/b2-canonical-20260923';query=repo/'.tmp/b2-query-20260923'
out=repo/'docs/audits/reports/2026-09/2026-09-23'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
subprocess.run(['python3',str(base/'check-source.py')],check=True,cwd=repo)
subprocess.run(['python3',str(base/'compare-instructions.py')],check=True,cwd=repo)
subprocess.run(['python3',str(base/'summarize.py')],check=True,cwd=repo)
measurements=json.loads((base/'measurements.json').read_text());inventory=json.loads((base/'artifacts.json').read_text())
assert set(measurements)=={r['id'] for r in inventory}
previous=json.loads((out/'b2-canonical-measurements.json').read_text())
records={};cumulative={};members={}
for artifact in inventory:
 aid=artifact['id'];row=measurements[aid];root=base/'results/after'/aid
 subprocess.run(['python3',str(base/'extract-bodies.py'),str(root),artifact['role']],check=True,stdout=subprocess.DEVNULL)
 record=json.loads((root/'canonical-storage-bodies.json').read_text());witness=json.loads((root/'canonical-bijection.json').read_text())
 assert record['canonical_sha256']==row['after']['sha256']
 assert witness['all_calls_preserved'] and witness['all_export_table_import_bindings_preserved'] and record['non_code_sections_exact']
 assert row['before']['sha256']==previous['measurements'][aid]['after']['sha256']
 for key in ['exports','role_cfgs','candid_sha256','generated_manifest_sha256']:
  assert row['after'].get(key)==previous['measurements'][aid]['before'].get(key),(aid,key)
 cumulative[aid]={key:row['after'][key]-previous['measurements'][aid]['before'][key] for key in row['delta']}
 records[aid]={
  'all_functions_bijective':record['all_functions_bijective'],
  'non_code_sections_exact':record['non_code_sections_exact'],
  'named_family_body_counts':{k:len(v) for k,v in record['selected_families'].items()},
  'evidence_sha256':{p.name:digest(p) for p in root.iterdir() if p.is_file()},
 }
 for path in root.iterdir():
  if (path.suffix in ['.json','.log','.txt','.did'] or path.name=='generated-Cargo.toml') and path.name not in ['sections.txt','link-map.txt','link-name-map.json']:
   members[f'after/{aid}/{path.name}']=path
root_record=json.loads((base/'results/after/root/canonical-storage-bodies.json').read_text())
assert not root_record['selected_families']['template_chunk_storage']
manifest_names=[r['name'] for r in root_record['selected_families']['control_plane_storage'] if '::template::manifest::' in r['name']]
prior_root=json.loads((old/'results/after/root/canonical-storage-bodies.json').read_text())
prior_manifest_names=[r['name'] for r in prior_root['selected_families']['control_plane_storage'] if '::template::manifest::' in r['name']]
assert sorted(manifest_names)==sorted(prior_manifest_names)
checks={
 'template_native':query/'root-native.log',
 'root_feature_clippy':query/'root-clippy.log',
 'core_metrics_native':base/'core-metrics-tests.log',
 'core_control_plane_all_target_clippy':base/'final-clippy.log',
 'root_store_pocketic':base/'root-pocketic.log',
 'document_semantics':base/'document-check.log',
}
for name,path in checks.items():
 text=path.read_text()
 assert 'error: could not compile' not in text,name
 if name.endswith('native'):assert 'test result: ok.' in text,name
 if 'clippy' in name:assert 'Finished ' in text,name
 if name=='root_store_pocketic':assert 'WORKSPACE TESTS PASSED' in text and '415s' in text
 members[f'checks/{name}.log']=path
method_names=['artifacts.json','source-manifest.json','changed-paths.txt','tools.json','build.sh','build.log','roster.tsv',
 'check-source.py','native-test-overlay.json','native-test-overlay.patch','summarize.py','wasm_metrics.py',
 'trace.sh','trace-ready.sh','trace.log','attach-link-names.py','map-functions.py','verify-map.py','extract-bodies.py',
 'retain.py','verify-retained.py','wrap-instructions.py','runtime-wrapper.log','full-query.py','warm-query.py','compare-instructions.py',
 'full-query/instruction-samples-first.json','full-query/instruction-samples-both.json','full-query/run.log','full-query/repeat.log',
 'warm-query-control/instruction-samples-both.json','warm-query-control/run.log','instruction-comparison.json']
for name in method_names:members[f'method/{name}']=base/name
for name in ['instructions/Cargo.toml','instructions/Cargo.lock','instructions/src/main.rs','attribute.py','borrow-history.py','finalize-history.py']:
 members[f'query-method/{name}']=query/name
for target in ['name','enabled','malloc']:
 for name in ['instruction-samples-both.json','run.log']:
  members[f'query-attribution/{target}/{name}']=query/f'attribute-{target}'/name
for name in ['capture-rustc.sh','wasm-replica-function-count.rs','harness/Cargo.toml','harness/src/main.rs','harness-Cargo.lock']:
 members[f'build-method/{name}']=old/name
for condition in ['before','after']:
 for kind in ['full-query','warm-query-control']:
  path=base/kind/'results'/condition/'runtime_probe/instruction-wrapped.wasm'
  assert path.exists(),path
# Raw payloads stay local; retain exact identities for reproducibility.
raw_identities={str(p.relative_to(repo)):digest(p) for p in [base/'after.tar.gz',old/'results/after/driver',query/'full-query/driver',base/'wasm-replica-function-count']}
for kind in ['full-query','warm-query-control']:
 for condition in ['before','after']:
  p=base/kind/'results'/condition/'runtime_probe/instruction-wrapped.wasm';raw_identities[str(p.relative_to(repo))]=digest(p)
files={name:digest(path) for name,path in members.items()}
members_manifest=json.dumps(files,indent=2).encode()+b'\n'
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as archive:
 for name,path in sorted(members.items()):
  data=path.read_bytes();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;archive.addfile(info,io.BytesIO(data))
 info=tarfile.TarInfo('member-sha256.json');info.size=len(members_manifest);info.mode=0o644;archive.addfile(info,io.BytesIO(members_manifest))
bundle=out/'b2-storage-closeout-records.tar.gz';bundle.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
groups={'canonical':[a['id'] for a in inventory if a['config']=='apps/test/canic.toml'],'fixtures':[a['id'] for a in inventory if a['config']!='apps/test/canic.toml']}
sums={name:{scope:{key:sum((measurements[aid]['delta'] if scope=='last_cut' else cumulative[aid])[key] for aid in aids) for key in measurements[aids[0]]['delta']} for scope in ['last_cut','cumulative_b2']} for name,aids in groups.items()}
report={
 'schema_version':1,'date':'2026-09-23','scope':'B2 completed storage ownership and accepted cold-query tradeoff',
 'complete_b2':True,'decision':'Stop B2 at push readiness; evaluate residual B3 record/codec value separately before implementation.',
 'build_speed_claim':False,'clean_repeat_claim':False,'broad_validation_run':False,
 'previous_report':{'file':'b2-canonical-measurements.json','sha256':digest(out/'b2-canonical-measurements.json')},
 'expected_artifacts':[a['id'] for a in inventory],'measured_artifacts':list(measurements),
 'source_manifest_sha256':digest(base/'source-manifest.json'),'native_only_overlay':json.loads((base/'native-test-overlay.json').read_text()),
 'tools':json.loads((base/'tools.json').read_text()),'frozen_limits':previous['frozen_limits'],
 'measurements':measurements,'cumulative_b2_deltas':cumulative,'group_sums':sums,'canonical_traces':records,
 'root_manifest_names_preserved':manifest_names,'root_template_chunk_named_bodies':0,
 'instructions':json.loads((base/'instruction-comparison.json').read_text()),
 'checks':{k:{'log_sha256':digest(p),'result':'pass'} for k,p in checks.items()},
 'raw_local_identities':raw_identities,'retained_records':{'file':bundle.name,'sha256':digest(bundle),'members':len(members)+1},
 'limitations':['One canonical build per condition; B5 owns final independent clean repetitions.',
  'No build-speed or process-resource claim.',
  'Named absence alone does not prove absence of inlined machinery; source reachability and complete canonical mappings accompany it.',
  'Four cold-query regressions accepted only for these measured B2 vectors; the general 1% allowance remains unchanged.',
  'Page cohort retained from accepted B1; no new five-width B2 slope claim.',
  'Raw Wasm, source archive and full linker maps remain in local measurement storage.'],
 'excluded_attempts':['Config borrowing and borrowed chronological history experiments were not adopted.',
  'Initial attribution control selected the wrong baseline malloc body; corrected matched function control alone retained.',
  'Initial targeted metrics test expectations retained the removed Bootstrap label; native-only assertions corrected and all 92 tests rerun successfully.']
}
(out/'b2-storage-closeout.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(sums,indent=2));print('retained',len(measurements),'artifacts;',len(members)+1,'records;',bundle.stat().st_size,'compressed bytes')
