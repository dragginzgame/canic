from pathlib import Path
import re,sys,subprocess
sys.path.insert(0,str(Path('.tmp/b2-canonical-20260923').resolve()))
from wasm_metrics import var
base=Path('.tmp/b2-canonical-20260923');out=Path('.tmp/b2-closeout-20260923/full-query')
def leb(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return b
for condition in ['before','after']:
 src=(base/'results/before/runtime_probe') if condition=='before' else Path('.tmp/b2-closeout-20260923/results/after/runtime_probe');wat=(src/'instruction-wrapped.wat').read_text();data=(src/'instruction-wrapped.wasm').read_bytes()
 nf=max(int(i) for i in re.findall(r'\(func \(;(\d+);\)',wat))+1;ng=max(int(i) for i in re.findall(r'\(global \(;(\d+);\)',wat))+1
 imports={name:int(i) for name,i in re.findall(r'\(import "ic0" "([^"]+)" \(func \(;(\d+);\)',wat)}
 query=int(re.search(r'\(export "canister_query qualify_history_query_cost" \(func (\d+)\)\)',wat)[1])
 wat=re.sub(r'\bcall '+str(imports['msg_reply'])+r'\b','call '+str(nf),wat)
 wat=wat.replace(f'(export "canister_query qualify_history_query_cost" (func {query}))',f'(export "canister_query qualify_history_query_cost" (func {nf+1}))')
 wrap=f'''(global (mut i32) (i32.const 0))
(func
 global.get {ng}
 i32.eqz
 if
 call {imports['msg_reply']}
 end)
(func (local i64)
 i32.const 1
 global.set {ng}
 i32.const 0
 call {imports['performance_counter']}
 local.set 0
 call {query}
 i32.const 0
 i32.const 0
 call {imports['performance_counter']}
 local.get 0
 i64.sub
 i64.store
 i32.const 0
 i32.const 8
 call {imports['msg_reply_data_append']}
 call {imports['msg_reply']})'''
 dest=out/'results'/condition/'runtime_probe';dest.mkdir(parents=True,exist_ok=True);w=dest/'full-query.wat';w.write_text(wat.rstrip()[:-1]+'\n'+wrap+'\n)\n');binary=dest/'instruction-wrapped.wasm';subprocess.run(['wat2wasm',str(w),'-o',str(binary)],check=True)
 original={};custom=[];p=8
 while p<len(data):
  kind=data[p];size,start=var(data,p+1);end=start+size
  if kind:original[kind]=data[start:end]
  else:custom.append(data[p:end])
  p=end
 b=binary.read_bytes();p=8
 while b[p]!=10:size,start=var(b,p+1);p=start+size
 if 12 in original:b=b[:p]+bytes([12])+leb(len(original[12]))+original[12]+b[p:]
 binary.write_bytes(b+b''.join(custom));subprocess.run(['wasm-validate',str(binary)],check=True)
