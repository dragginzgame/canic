from pathlib import Path
import json,hashlib
base=Path(__file__).resolve().parent
cold=json.loads((base/'full-query/instruction-samples-both.json').read_text())
first=json.loads((base/'full-query/instruction-samples-first.json').read_text())
warm=json.loads((base/'warm-query-control/instruction-samples-both.json').read_text())
assert cold==first
key=lambda x:tuple(x[k] for k in ['condition','rows','lifecycle','access'])
warm_by={key(x):x for x in warm['samples']}
for sample in cold['samples']:
 control=warm_by[key(sample)]
 for k in sample:
  if k not in ['query_instructions','full_query_instructions']:assert sample[k]==control[k],(key(sample),k)
 assert (sample['full_query_instructions']-control['full_query_instructions'])%80000==0
before=[x for x in cold['samples'] if x['condition']=='before'];after=[x for x in cold['samples'] if x['condition']=='after'];rows=[]
for a,b in zip(before,after):
 assert key(a)[1:]==key(b)[1:]
 wa,wb=warm_by[key(a)],warm_by[key(b)]
 row={k:b[k] for k in ['rows','lifecycle','access']}
 for metric in ['export_instructions','callback_instructions','query_instructions','full_query_instructions']:
  row[metric]={'before':a[metric],'after':b[metric],'delta':b[metric]-a[metric],'percent':100*(b[metric]/a[metric]-1)}
 row['warm_full_query']={'before':wa['full_query_instructions'],'after':wb['full_query_instructions'],'percent':100*(wb['full_query_instructions']/wa['full_query_instructions']-1)}
 row['first_touch_charge_delta']=(b['full_query_instructions']-wb['full_query_instructions'])-(a['full_query_instructions']-wa['full_query_instructions'])
 assert row['warm_full_query']['percent']<=1
 rows.append(row)
result={'schema_version':1,'cold_repeat_exact':True,'warm_control_update_state_unchanged':True,'first_touch_control_scope':'Write identical bytes once per 4096-byte region before the query counter; only an attribution control, excluded from qualification.', 'charge_quantum_instructions':80000,'rows':rows,'all_sampling_within_one_percent':all(r['export_instructions']['percent']<=1 for r in rows),'all_cold_queries_within_one_percent':all(r['full_query_instructions']['percent']<=1 for r in rows),'all_warm_controls_within_one_percent':True,'cold_query_exception_accepted':True, 'acceptance_authority':'Maintainer explicitly accepted the four measured B2 cold-query regressions on 2026-09-23; 1% remains applicable elsewhere.','maximum_extra_query_instructions':max(r['full_query_instructions']['delta'] for r in rows),'maximum_first_touch_charge_delta':max(r['first_touch_charge_delta'] for r in rows),'lifecycle':cold['lifecycle']}
(base/'instruction-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('repeat exact; sampling within 1%; four cold query regressions; warm controls within 1%; largest extra cold-query cost:',result['maximum_extra_query_instructions'])
